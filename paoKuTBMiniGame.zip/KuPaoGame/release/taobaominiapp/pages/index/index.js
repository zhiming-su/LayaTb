"use strict";/**window.screenOrientation="sensor_landscape",*/delete require.cache[require.resolve("layaengine/libs/min/laya.core.min.js")];
require("layaengine/libs/min/laya.core.min.js"),delete require.cache[require.resolve("layaengine/libs/min/laya.ui.min.js")];
require("layaengine/libs/min/laya.ui.min.js"),delete require.cache[require.resolve("layaengine/libs/min/laya.d3.min.js")];
require("layaengine/libs/min/laya.d3.min.js"),delete require.cache[require.resolve("./../../platform.js")];
require("./../../platform.js"),delete require.cache[require.resolve("./js/bundle.js")];
require("./js/bundle.js");