/**! __CODEPLACEHOLDER_START__ */ /*[PositionForClientEntryCodeBegin]*/ /**! __CODEPLACEHOLDER_END__ */
require('@alipay/appx-compiler/lib/sjsEnvInit');
require('./config$');

require('../../pages/home/home?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
require('../../pages/index/game?hash=5158fa18297db3fbaac119609b168d20fcdf1eea');
