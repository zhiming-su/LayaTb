export default class Time extends Laya.Script {
   
    public static fixedDeltaTime=0;
    public static deltaTime=0;
    public static time=0;
    

    public static deltaTimeMin=9999999999999999;
    public static deltaTimeMax=0;
    public static deltaTimeEvr=0;
}