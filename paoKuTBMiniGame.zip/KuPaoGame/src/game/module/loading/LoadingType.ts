/*
 * @Date: 2021-06-08 19:26:15
 * @Author: xlc
 * @LastEditors: xlc
 * @LastEditTime: 2021-06-08 20:41:51
 * @description: 
 */
export enum LoadingType{
    InitGame = 1,//进入主页
    EnterGame = 2//进入游戏
}