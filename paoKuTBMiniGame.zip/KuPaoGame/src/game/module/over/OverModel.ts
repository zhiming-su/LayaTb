import BaseModel from "../../../core/base/BaseModel";

/*
 * @Date: 2021-07-03 14:47:14
 * @Author: xlc
 * @LastEditors: xlc
 * @LastEditTime: 2021-07-03 14:49:49
 * @description: 
 */
export default class OverMoedl extends BaseModel{
    constructor(){
        super()
    }
}
