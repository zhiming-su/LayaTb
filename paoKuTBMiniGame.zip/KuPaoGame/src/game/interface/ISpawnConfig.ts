/*
 * @Date: 2021-06-19 11:32:38
 * @Author: xlc
 * @LastEditors: xlc
 * @LastEditTime: 2021-06-19 11:33:53
 * @description: 
 */
export interface ISpawnConfig{
    row:number
    gold:Array<number>
    obstacle:Array<number>
}