/*
 * @Date: 2021-06-09 10:44:28
 * @Author: xlc
 * @LastEditors: xlc
 * @LastEditTime: 2021-06-09 14:31:09
 * @description: 
 */
import MonoBehaviour from "../../unityEngine/MonoBehaviour";

export class Rat extends MonoBehaviour {
    m_CurrentPos = 0;
    m_MaxSpeed = 0;
    m_OriginalPosition: Laya.Vector3;
    onStart() {
        
    }

    onUpdate() {
        

    }
}