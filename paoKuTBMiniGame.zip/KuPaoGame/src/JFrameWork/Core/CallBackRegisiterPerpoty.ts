export default class CallBackRegisiterPerpoty  {
    constructor() {
    }

    regisiter;
    CallbackFunc: Function
    
}