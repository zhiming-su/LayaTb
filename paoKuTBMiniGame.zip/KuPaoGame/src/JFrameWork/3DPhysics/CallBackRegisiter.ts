/*
 * @Date: 2021-06-15 10:27:15
 * @Author: xlc
 * @LastEditors: xlc
 * @LastEditTime: 2021-06-15 16:02:23
 * @description: 
 */
export default class CallBackRegisiter {

    constructor() {
    }

    regisiter;
    enterCallbackFunc: Function
    ExitCallbackFunc: Function
}