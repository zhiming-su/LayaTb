
export default class GameDesgin {

  //碰撞体线
  public static showaabbBoxLine = !!0;

  public static enableCollsion = !!1;

  public static logFps = false;

  public static spwanFish = true;

  public static spwanObstacle = true;

}