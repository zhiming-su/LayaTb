export class EventType{

    public static ShapeThreeDEnterWorld='ShapeThreeDEnterWorld';
 
    public static AD_VIDEO_CLOSE_EVENT='AD_VIDEO_CLOSE_EVENT';

    public static WxOnShow='WxOnShow';

    public static SHARE_Ok='SHARE_Ok';

    public static UpdateGoldItemUi='UpdateGoldItemUi';

    public static ShopSelectChrater='onSelectChrater';
    public static ShopSelectHat='ShopSelectHat';

    public static CharaterIniOk='CharaterIniOk';
}