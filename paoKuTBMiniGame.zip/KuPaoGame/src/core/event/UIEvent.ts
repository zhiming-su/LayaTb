export default class UIEvent{
    /**ui打开 */
    static OPEN:string = "Open"
    /**UI关闭 */
    static CLOSE:string = "Close"
}