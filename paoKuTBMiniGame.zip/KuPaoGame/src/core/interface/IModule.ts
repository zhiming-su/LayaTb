import BaseModel from "../base/BaseModel";

/*
 * @Date: 2021-06-07 09:49:52
 * @Author: xlc
 * @LastEditors: xlc
 * @LastEditTime: 2021-06-16 15:40:19
 * @description: 
 */
export default interface IModule{
    openWindow(callback:Function):void
}