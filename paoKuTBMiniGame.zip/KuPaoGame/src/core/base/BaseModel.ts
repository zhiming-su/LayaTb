/*
 * @Date: 2021-06-07 09:45:33
 * @Author: xlc
 * @LastEditors: xlc
 * @LastEditTime: 2021-06-07 11:42:23
 * @description: 
 */
export default class BaseModel extends Laya.EventDispatcher{
    constructor(){
        super()
    }

    public regist():void{

    }

    public destory():void{
        
    }
}