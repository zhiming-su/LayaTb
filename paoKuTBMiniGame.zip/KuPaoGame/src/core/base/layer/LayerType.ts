/*
 * @Date: 2021-06-03 19:55:41
 * @Author: xlc
 * @LastEditors: xlc
 * @LastEditTime: 2021-06-08 21:01:13
 * @description: 
 */
export enum LayerType{
    Scene3D,
    UI,
    Tip
}