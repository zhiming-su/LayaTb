"use strict";/**window.screenOrientation="sensor_landscape",*/delete require.cache[require.resolve("layaengine/libs/laya.core.js")];
require("layaengine/libs/laya.core.js"),delete require.cache[require.resolve("layaengine/libs/laya.ui.js")];
require("layaengine/libs/laya.ui.js"),delete require.cache[require.resolve("layaengine/libs/laya.physics.js")];
require("layaengine/libs/laya.physics.js"),delete require.cache[require.resolve("./../../platform.js")];
require("./../../platform.js"),delete require.cache[require.resolve("./js/bundle.js")];
require("./js/bundle.js");