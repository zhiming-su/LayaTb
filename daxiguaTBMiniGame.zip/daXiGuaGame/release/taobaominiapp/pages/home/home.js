Page({
  data: {},
  onLoad() { },
  goToUrl() {
    my.navigateTo({
      url: '/pages/daxigua/game'
    });
  },
});
