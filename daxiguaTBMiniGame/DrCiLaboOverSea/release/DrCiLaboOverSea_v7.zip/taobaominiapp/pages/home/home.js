Page({
  data: {},
  onLoad() { },
  goToUrl() {
    my.navigateTo({
      url: '/pages/index/game'
    });
  },
});
