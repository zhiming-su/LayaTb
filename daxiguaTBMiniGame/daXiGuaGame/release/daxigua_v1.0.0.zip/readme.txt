
注意事项：

1、app.json文件中添加参数
        "enableSkia": true
		
2、mini.project.json 允许的文件格式	

3、node_modules\layaengine目录  laya引擎，切记添加
		
4、pages\index  游戏小程序工程

5、音效文件目录pages\index\res\sounds

6、音效接口platform.js  =》 playSound() 方法

